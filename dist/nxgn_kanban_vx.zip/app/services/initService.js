// app/services/initService.js

// Import Pinia Stores
import { useUiStore } from '../store/uiStore.js';
import { useLookupsStore } from '../store/lookupsStore.js';
import { useUserStore } from '../store/userStore.js';
import { useProjectsStore } from '../store/projectsStore.js';
import { useModalStore } from '../store/modalStore.js';

// Import Local Storage Utilities
import { LS_KEYS, loadSetting } from '../utils/localStorage.js';

// --- CORRECT Import ZohoAPIService ---
import ZohoAPIService from './zohoCreatorAPI.js';

/**
 * Initializes the application by fetching essential data for initial display
 * and then fetching secondary data in the background.
 * Manages global loading and error states via the UI store.
 */
export async function initializeApp() {
  // Get instances of all necessary stores *inside* the function
  const uiStore = useUiStore();
  const lookupsStore = useLookupsStore();
  const userStore = useUserStore();
  const projectsStore = useProjectsStore();
  const modalStore = useModalStore();

  // --- Fetch and Log Query Params (Fire and Forget) ---
  ZohoAPIService.getQueryParams()
    .then(queryParams => {
        console.log("App Init Service: Parent Query Params:", queryParams);
        // You can store or use queryParams here if needed later
    })
    .catch(error => {
        // Error is already logged in the service, but we could log context here
        console.error("App Init Service: Failed to get query params during init.");
    });

  console.log("App Init Service: Starting initialization...");
  uiStore.setGlobalLoading(true);
  uiStore.setGlobalError(null);

  try {
    // --- Phase 1: Fetch Core Data for Initial Render (Awaited) ---
    console.log("App Init Service: Fetching Core Lookups (Stages/Tranches) and Initial Projects...");
    
    // Fetch Core Lookups (Stages, Tranches, Users) and Projects concurrently
    await Promise.all([
        lookupsStore.fetchCoreLookups(),
        projectsStore.fetchInitialProjects()
    ]);
    
    console.log("App Init Service: Core Lookups (Stages/Tranches) and Projects fetched.");

    // --- Fetch Current User (Depends on Core Lookups) --- 
    console.log("App Init Service: Fetching Current User...");
    // User fetch is now independent of lookups store
    await userStore.fetchCurrentUser();
    console.log("App Init Service: User fetched.");

    // --- Restore Modal State (Can run after user context is potentially available) ---
    // This can run regardless of user fetch success, but might depend on project ID
    const savedModalState = loadSetting(LS_KEYS.ACTIVE_MODAL, null);
    if (savedModalState && savedModalState.expiresAt && savedModalState.expiresAt > Date.now()) {
      console.log("App Init Service: Found valid saved modal state...");
      modalStore.openModal(savedModalState.projectId);
    } else if (savedModalState) {
      console.log("App Init Service: Found expired modal state. Clearing...");
      localStorage.removeItem(LS_KEYS.ACTIVE_MODAL);
    }

    // --- Phase 1 Complete: Initial render can happen now ---
    console.log("App Init Service: Phase 1 (Core data) completed. Setting global loading false.");
    uiStore.setGlobalLoading(false); // <<<=== SET LOADING FALSE HERE

    // --- Phase 2: Fetch Filter Lookups (Tags, Reps, Orgs) - Fire and Forget ---
    // These are not awaited, they run in the background after initial render.
    // No need to explicitly call them here, they will be fetched on demand by the toolbar.
    console.log("App Init Service: Filter lookups (Tags, Reps, Orgs) will be fetched on demand.");
    
    console.log("App Init Service: Initialization sequence finished.");

  } catch (error) {
    // Catch errors from Promise.all or fetchCurrentUser if they re-throw
    console.error("App Init Service: CRITICAL ERROR during initialization sequence:", error);
    // Use the error already set in the specific store action if possible,
    // or set a generic one.
    if (!uiStore.globalError) { // Don't overwrite specific errors if stores set them
         uiStore.setGlobalError(`Initialization failed: ${error.message || 'Unknown error'}`);
    }
    // Ensure loading is false even if phase 1 errors out
    uiStore.setGlobalLoading(false); 
  }
  // REMOVE finally block as loading is set earlier
  // finally {
  //   uiStore.setGlobalLoading(false);
  //   console.log("App Init Service: Global loading state set to false.");
  // }
} 